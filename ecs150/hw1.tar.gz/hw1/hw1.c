/* 	Wai Shing Yung
	996936848
	ECS 150 hw 1
*/

#include <sys/types.h>
#include <sys/param.h>
#include <sys/proc.h>
#include <sys/module.h>
#include <sys/sysent.h>
#include <sys/kernel.h>
#include <sys/systm.h>
#include <sys/lock.h>
#include <sys/mutex.h>

// Declaring the syscallname_args structure	
struct setProcessTickets_args{
	int pid; 
	int tickets;
};
struct getProcessTickets_args{
	int pid;};
struct setSocialInfo_args{
	int pid; 
	u_int64_t social_info;
}; 
struct getSocialInfo_args{
	int pid;
};
struct setLotteryMode_args{
	int mode;
};

//Function prototype
static int setProcessTickets(struct thread *td, struct setProcessTickets_args *arg);
static int getProcessTickets(struct thread *td, struct getProcessTickets_args *arg);
static int setSocialInfo(struct thread *td, struct setSocialInfo_args *arg);
static int getSocialInfo(struct thread *td, struct getSocialInfo_args *arg);
static int setLotteryMode(struct thread *td, struct setLotteryMode_args *arg);
static int getLotteryMode(struct thread *td);

//====================================================================================
//int setProcessTickets(int pid, int tickets);
static int setProcessTickets(struct thread *td, struct setProcessTickets_args *arg){
	int x = arg->pid; //pid
	int y = arg->tickets; //tickets
	struct proc *p1 = pfind(x); 
	if (p1 != NULL){
		p1->tickets = y;
		PROC_UNLOCK(p1);
		td->td_retval[0] = p1->tickets;
	}
	else{
		td->td_retval[0] = -1;
	}
	return 0;
}
static struct sysent setProcessTickets_sysent = { 2, setProcessTickets };
static int offset1 = NO_SYSCALL;
static int load_setProcessTickets(struct module *module, int cmd, void *arg){
	int error = 0;
	switch (cmd){
	case MOD_LOAD:
		printf("syscall loaded at %d\n", offset1);
		break;
	case MOD_UNLOAD:
		printf("syscall unloaded at %d\n", offset1);
		break;
	default:
		error = EINVAL;
		break;
	}
	return error;
}
SYSCALL_MODULE(setProcessTickets, &offset1, &setProcessTickets_sysent, load_setProcessTickets, NULL);

//====================================================================================
//int getProcessTickets(int pid);
static int getProcessTickets(struct thread *td, struct getProcessTickets_args *arg){
  	int x = arg->pid;	// ticket
  	struct proc *p1 = pfind(x);
  	if (p1 != NULL){
      	int y = p1->tickets;
      	PROC_UNLOCK(p1);
      	td->td_retval[0] = y;
    }
  	else{
      	td->td_retval[0] = -1;
    }
  return 0;
}
static struct sysent getProcessTickets_sysent = { 1, getProcessTickets };
static int offset2 = NO_SYSCALL;
static int load_getProcessTickets(struct module *module, int cmd, void *arg){
	int error = 0;
	switch (cmd){
	case MOD_LOAD:
		printf("syscall loaded at %d\n", offset2);
		break;
	case MOD_UNLOAD:
		printf("syscall unloaded at %d\n", offset2);
		break;
	default:
		error = EINVAL;
		break;
	}
	return error;
}
SYSCALL_MODULE(getProcessTickets, &offset2, &getProcessTickets_sysent, load_getProcessTickets, NULL);

//====================================================================================
//int setSocialInfo(int pid, u_int64_t social_info);
static int setSocialInfo(struct thread *td, struct setSocialInfo_args *arg){
	int x = arg->pid; //pid
	// u_int64_t y = arg->social_info; //social_info	
	struct proc *p1 = pfind(x); 
	if (p1 != NULL){
		p1->social_info = arg->social_info;
		PROC_UNLOCK(p1);
		td->td_retval[0] = p1->social_info;
	}
	else{
		td->td_retval[0] = -1;
	}
	return 0;
}
static struct sysent setSocialInfo_sysent = { 2, setSocialInfo };
static int offset3 = NO_SYSCALL;
static int load_setSocialInfo(struct module *module, int cmd, void *arg){
	int error = 0;
	switch (cmd){
	case MOD_LOAD:
		printf("syscall loaded at %d\n", offset3);
		break;
	case MOD_UNLOAD:
		printf("syscall unloaded at %d\n", offset3);
		break;
	default:
		error = EINVAL;
		break;
	}
	return error;
}
SYSCALL_MODULE(setSocialInfo, &offset3, &setSocialInfo_sysent, load_setSocialInfo, NULL);

//====================================================================================
//u_int64_t getSocialInfo(int pid);
static int getSocialInfo(struct thread *td, struct getSocialInfo_args *arg){
  	int x = arg->pid;	// ticket
  	struct proc *p1 = pfind(x);
  	if (p1 != NULL){
      	u_int64_t y = p1->social_info;
      	PROC_UNLOCK(p1);
      	td->td_retval[0] = y;
    }
  	else{
      	td->td_retval[0] = -1;
    }
    return 0;
}
static struct sysent getSocialInfo_sysent = { 1, getSocialInfo };
static int offset4 = NO_SYSCALL;
static int load_getSocialInfo(struct module *module, int cmd, void *arg){
	int error = 0;
	switch (cmd){
	case MOD_LOAD:
		printf("syscall loaded at %d\n", offset4);
		break;
	case MOD_UNLOAD:
		printf("syscall unloaded at %d\n", offset4);
		break;
	default:
		error = EINVAL;
		break;
	}
	return error;
}
SYSCALL_MODULE(getSocialInfo, &offset4, &getSocialInfo_sysent, load_getSocialInfo, NULL);

//====================================================================================
//int setLotteryMode(int mode);
static int setLotteryMode(struct thread *td, struct setLotteryMode_args *arg){
  	lottery_mode = arg->mode;
	return 0;
}
static struct sysent setLotteryMode_sysent = { 1, setLotteryMode };
static int offset5 = NO_SYSCALL;
static int load_setLotteryMode(struct module *module, int cmd, void *arg){
	int error = 0;
	switch (cmd){
	case MOD_LOAD:
		printf("syscall loaded at %d\n", offset5);
		break;
	case MOD_UNLOAD:
		printf("syscall unloaded at %d\n", offset5);
		break;
	default:
		error = EINVAL;
		break;
	}
	return error;
}
SYSCALL_MODULE(setLotteryMode, &offset5, &setLotteryMode_sysent, load_setLotteryMode, NULL);

//====================================================================================
//int getLotteryMode(void);
static int getLotteryMode(struct thread *td){
    td->td_retval[0] = lottery_mode;
	return 0;
}
static struct sysent getLotteryMode_sysent = { 0, getLotteryMode };
static int offset6 = NO_SYSCALL;
static int load_getLotteryMode(struct module *module, int cmd, void *arg){
	int error = 0;
	switch (cmd){
	case MOD_LOAD:
		printf("syscall loaded at %d\n", offset6);
		break;
	case MOD_UNLOAD:
		printf("syscall unloaded at %d\n", offset6);
		break;
	default:
		error = EINVAL;
		break;
	}
	return error;
}
SYSCALL_MODULE(getLotteryMode, &offset6, &getLotteryMode_sysent, load_getLotteryMode, NULL);


