996936848,Wai shing Yung
998532279, Meng-Hsuan Lee

Collaborated on writing the loop and implementing lottery mode by discussing notes from the TA as well as discussion slides. One person did the initial if statement to count the tickets and the other person implemented the actual lottery mode.